export enum FeatureView {
  VideoUnderstanding = 'video_understanding',
  ImageUnderstanding = 'image_understanding',
  ImageGeneration = 'image_generation',
  VeoAnimation = 'veo_animation',
  ImageEditing = 'image_editing',
  UGCGenerator = 'ugc_generator',
}

export interface NavItem {
  id: FeatureView;
  label: string;
  icon: string;
  description: string;
}

// Extend Window interface for Veo API Key selection
declare global {
  // Fix: 'aistudio' is already declared on Window with type 'AIStudio'.
  // We must augment the interface 'AIStudio' to add the missing methods
  // rather than redeclaring the property on Window which causes a type conflict.
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }
}