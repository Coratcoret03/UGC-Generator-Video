import { GoogleGenAI, Modality, Type } from "@google/genai";

// Helper to get AI instance - ALWAYS creates new instance to pick up fresh keys
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper for file to base64
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data URL prefix (e.g., "data:image/jpeg;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// 1. Video Understanding (Gemini 2.5 Pro)
export const analyzeVideo = async (videoFile: File, prompt: string) => {
  const ai = getAI();
  const base64Video = await fileToBase64(videoFile);

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: videoFile.type,
            data: base64Video
          }
        },
        { text: prompt }
      ]
    }
  });
  return response.text;
};

// 2. Image Understanding (Gemini 2.5 Flash)
export const analyzeImage = async (imageFile: File, prompt: string) => {
  const ai = getAI();
  const base64Image = await fileToBase64(imageFile);

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: imageFile.type,
            data: base64Image
          }
        },
        { text: prompt }
      ]
    }
  });
  return response.text;
};

// 3. Image Generation (Imagen 4)
export const generateImage = async (prompt: string, numberOfImages: number = 1, aspectRatio: string = '1:1') => {
  const ai = getAI();
  const response = await ai.models.generateImages({
    model: 'imagen-4.0-generate-001',
    prompt: prompt,
    config: {
      numberOfImages: numberOfImages,
      outputMimeType: 'image/jpeg',
      aspectRatio: aspectRatio,
    },
  });
  
  if (!response.generatedImages) {
    return [];
  }

  return response.generatedImages.map(img => 
    `data:image/jpeg;base64,${img.image.imageBytes}`
  );
};

// 4. Veo Video Animation
export const generateVeoVideo = async (imageFile: File, prompt: string, aspectRatio: '16:9' | '9:16' = '16:9') => {
  const ai = getAI();
  const base64Image = await fileToBase64(imageFile);

  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: prompt || "Animate this image cinematically.",
    image: {
      imageBytes: base64Image,
      mimeType: imageFile.type,
    },
    config: {
      numberOfVideos: 1,
      resolution: '720p', // Fast preview usually 720p
      aspectRatio: aspectRatio
    }
  });

  // Polling
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 5000)); // Poll every 5s
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed or returned no URI");

  // Fetch binary with API Key
  const videoRes = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await videoRes.blob();
  return URL.createObjectURL(blob);
};

// 5. Image Editing (Gemini 2.5 Flash Image / Nano Banana)
export const editImage = async (imageFile: File, prompt: string) => {
  const ai = getAI();
  const base64Image = await fileToBase64(imageFile);

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image,
            mimeType: imageFile.type,
          },
        },
        {
          text: prompt,
        },
      ],
    },
    config: {
      responseModalities: [Modality.IMAGE],
    },
  });

  // Extract image
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("No image returned from editing model.");
};

// 6. UGC Generator (Gemini 2.5 Pro for creative writing)
export const generateUGCScript = async (
  productName: string,
  productType: string,
  targetAudience: string,
  platform: string,
  tone: string,
  benefits: string
) => {
  const ai = getAI();
  
  const systemPrompt = `You are an expert UGC creator and high-performing video marketer. 
  Your task is to generate a complete UGC video concept that is persuasive, natural, relatable, and optimized for social media conversion. 
  Always write from the perspective of a real user who has tried and experienced the product. 
  Keep it authentic, convincing, and engaging.
  Use Indonesian language (Bahasa Indonesia) for the script content.
  
  VIDEO PRODUCTION GUIDANCE:
  - Output wajib berbentuk format ready-to-produce, scene-by-scene dengan timestamp.
  - Tiap scene mencakup (wajib): visual + dialog/voiceover + teks overlay + arah kamera.
  - Arah Kamera: close up tangan, POV (dari sudut pandang pengguna), atau handheld untuk kesan real.
  - Lighting: rekomendasi natural daylight atau soft lighting dalam ruangan.
  - Gerakan Kamera: slow pan atau sedikit shaky (supaya terlihat natural UGC).
  - Editing: Perpindahan antar scene gunakan cut cepat/pelan sesuai emosi.
  - Overlay text maksimal 4 kata tiap muncul, sertakan timing detik kemunculannya.
  - Tuliskan instruksi kapan sound effect atau efek visual muncul.
  - Voiceover: sebutkan gaya (misal: wanita muda, semangat namun tulus), sinkron dengan visual.
  - Background Music: rekomendasikan vibe musik (tanpa sebut judul).
  
  Tone: Natural, relatable, seolah ngobrol ke teman (bukan script formal).
  Format Konten: Testimoni + storytelling singkat + demonstrasi produk.
  Durasi Target: 30–45 detik.
  `;

  const userPrompt = `
  Create 1 complete UGC video concept (9:16 format) to promote product:
  ${productName} - ${productType}

  Target audiens: ${targetAudience}
  Platform utama: ${platform}
  Tone: ${tone}
  Benefit utama: ${benefits}

  Buatkan 1 konsep UGC video lengkap bergaya creator asli, mencakup:
  📍 1. Judul Konsep Video
  📍 2. Script spoken (dialog natural, gaya bicara manusia)
  📍 3. Scene breakdown per detik (termasuk angle kamera & ekspresi)
  📍 4. Teks overlay (maks 4 kata per overlay)
  📍 5. Narasi alternatif (cadangan A/B testing)
  📍 6. Hook awal (3 detik paling menarik)
  📍 7. Benefit utama + emotional trigger
  📍 8. CTA akhir (soft selling)
  📍 9. Caption rekomendasi + emoji + CTA
  📍 10. Hashtag relevan (maks 7 hashtag)

  Berikan opsi variasi gaya konten (testimoni, unboxing, before-after, POV, story-telling)
  Sertakan ide CTA yang berbeda (diskon, klik keranjang, link bio, dll)

  Formatkan respons dengan Markdown heading yang jelas.
  `;

  const response = await ai.models.generateContentStream({
    model: 'gemini-2.5-pro',
    contents: userPrompt,
    config: {
      systemInstruction: systemPrompt,
    }
  });

  return response;
};