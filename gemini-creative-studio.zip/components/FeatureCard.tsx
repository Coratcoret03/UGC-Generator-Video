import React from 'react';

interface FeatureCardProps {
  title: string;
  description: string;
  icon: string;
  children: React.ReactNode;
}

export const FeatureCard: React.FC<FeatureCardProps> = ({ title, description, icon, children }) => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-6 md:p-8 shadow-2xl">
        <div className="flex items-center mb-6 border-b border-slate-700 pb-4">
          <div className="p-3 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400 mr-4">
            <i className={`text-2xl ${icon}`}></i>
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">{title}</h2>
            <p className="text-slate-400">{description}</p>
          </div>
        </div>
        <div className="space-y-6">
          {children}
        </div>
      </div>
    </div>
  );
};