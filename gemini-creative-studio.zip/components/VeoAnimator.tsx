import React, { useState, useEffect } from 'react';
import { generateVeoVideo } from '../services/geminiService';
import { Button } from './Button';
import { FeatureCard } from './FeatureCard';

export const VeoAnimator: React.FC = () => {
  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [loading, setLoading] = useState(false);
  const [videoUrl, setVideoUrl] = useState('');
  const [hasKey, setHasKey] = useState(false);

  useEffect(() => {
    // Check for Veo API key selection
    const checkKey = async () => {
      if (window.aistudio && window.aistudio.hasSelectedApiKey) {
        try {
          const has = await window.aistudio.hasSelectedApiKey();
          setHasKey(has);
        } catch (e) {
          console.error("Error checking API key status", e);
        }
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    if (window.aistudio && window.aistudio.openSelectKey) {
      try {
        await window.aistudio.openSelectKey();
        setHasKey(true); // Optimistic update
      } catch (e) {
        console.error("Error selecting key", e);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImage(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleGenerate = async () => {
    if (!image) return;
    setLoading(true);
    setVideoUrl('');
    try {
      const url = await generateVeoVideo(image, prompt, aspectRatio);
      setVideoUrl(url);
    } catch (error: any) {
      console.error(error);
      if (error.message && error.message.includes("Requested entity was not found")) {
        setHasKey(false);
        alert("API Key session expired or invalid. Please select key again.");
      } else {
        alert('Failed to generate video. Ensure prompt is valid and Veo is enabled.');
      }
    } finally {
      setLoading(false);
    }
  };

  if (!hasKey) {
     return (
       <FeatureCard
        title="Veo Animator"
        description="Animate static images into high-quality videos."
        icon="fa-solid fa-film"
       >
         <div className="text-center py-12">
           <i className="fa-solid fa-key text-4xl text-indigo-500 mb-4"></i>
           <h3 className="text-xl font-bold text-white mb-2">API Key Selection Required</h3>
           <p className="text-slate-400 mb-6 max-w-md mx-auto">
             Veo video generation requires you to select a billing-enabled API key for this session.
           </p>
           <div className="flex flex-col gap-4 items-center">
            <Button onClick={handleSelectKey}>
              Select API Key
            </Button>
            <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="text-xs text-indigo-400 hover:underline">
              View Billing Documentation
            </a>
           </div>
         </div>
       </FeatureCard>
     );
  }

  return (
    <FeatureCard
      title="Veo Animator"
      description="Turn your photos into cinematic videos using Veo 3.1 Fast Preview."
      icon="fa-solid fa-film"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="border-2 border-dashed border-slate-600 rounded-xl p-8 text-center hover:bg-slate-800/50 transition-colors">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
              id="veo-upload"
            />
            <label htmlFor="veo-upload" className="cursor-pointer flex flex-col items-center">
              <i className="fa-solid fa-image text-4xl text-indigo-500 mb-4"></i>
              <span className="text-slate-300">Upload Image to Animate</span>
            </label>
          </div>

          {preview && (
             <img src={preview} alt="Source" className="w-full h-48 object-cover rounded-lg border border-slate-700" />
          )}

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Prompt (Optional)</label>
            <input
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the movement (e.g., The water flows rapidly)"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Aspect Ratio</label>
            <div className="flex space-x-4">
              <label className={`flex items-center px-4 py-2 rounded-lg border cursor-pointer ${aspectRatio === '16:9' ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-slate-800 border-slate-600 text-slate-300'}`}>
                <input type="radio" className="hidden" checked={aspectRatio === '16:9'} onChange={() => setAspectRatio('16:9')} />
                <i className="fa-solid fa-tv mr-2"></i> Landscape (16:9)
              </label>
              <label className={`flex items-center px-4 py-2 rounded-lg border cursor-pointer ${aspectRatio === '9:16' ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-slate-800 border-slate-600 text-slate-300'}`}>
                <input type="radio" className="hidden" checked={aspectRatio === '9:16'} onChange={() => setAspectRatio('9:16')} />
                <i className="fa-solid fa-mobile-screen mr-2"></i> Portrait (9:16)
              </label>
            </div>
          </div>

          <Button
            onClick={handleGenerate}
            disabled={!image}
            isLoading={loading}
            className="w-full"
            icon="fa-solid fa-video"
          >
            Generate Video
          </Button>
        </div>

        <div className="bg-slate-900 rounded-xl flex items-center justify-center min-h-[300px] border border-slate-700 overflow-hidden relative">
          {loading ? (
             <div className="text-center text-indigo-400">
               <i className="fa-solid fa-circle-notch fa-spin text-3xl mb-2"></i>
               <p className="animate-pulse">Generating video... this may take a minute.</p>
             </div>
          ) : videoUrl ? (
            <div className="w-full h-full flex flex-col">
               <video controls autoPlay loop className="w-full h-auto max-h-[400px]">
                 <source src={videoUrl} type="video/mp4" />
               </video>
               <a href={videoUrl} download="veo_generated.mp4" className="text-center py-2 text-indigo-400 hover:text-indigo-300 text-sm bg-slate-900 w-full">
                 Download Video
               </a>
            </div>
          ) : (
            <div className="text-slate-500 text-center">
              <i className="fa-solid fa-clapperboard text-4xl mb-2"></i>
              <p>Generated video will appear here</p>
            </div>
          )}
        </div>
      </div>
    </FeatureCard>
  );
};