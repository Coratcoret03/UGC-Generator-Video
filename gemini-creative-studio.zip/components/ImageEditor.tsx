import React, { useState } from 'react';
import { editImage } from '../services/geminiService';
import { Button } from './Button';
import { FeatureCard } from './FeatureCard';

export const ImageEditor: React.FC = () => {
  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [resultImage, setResultImage] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImage(file);
      setPreview(URL.createObjectURL(file));
      setResultImage('');
    }
  };

  const handleEdit = async () => {
    if (!image || !prompt) return;
    setLoading(true);
    try {
      const output = await editImage(image, prompt);
      setResultImage(output);
    } catch (error) {
      console.error(error);
      alert('Failed to edit image');
    } finally {
      setLoading(false);
    }
  };

  return (
    <FeatureCard
      title="Nano Banana Editor"
      description="Edit images using natural language instructions with Gemini 2.5 Flash Image."
      icon="fa-solid fa-wand-magic-sparkles"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="border-2 border-dashed border-slate-600 rounded-xl p-8 text-center hover:bg-slate-800/50 transition-colors">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
              id="edit-upload"
            />
            <label htmlFor="edit-upload" className="cursor-pointer flex flex-col items-center">
              <i className="fa-solid fa-cloud-arrow-up text-4xl text-indigo-500 mb-4"></i>
              <span className="text-slate-300">Click to upload source image</span>
            </label>
          </div>

          {preview && (
            <div className="relative group">
               <img src={preview} alt="Original" className="w-full rounded-lg shadow-lg" />
               <div className="absolute top-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">Original</div>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Edit Instruction</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., Add a retro filter, remove the background person, make it snowy..."
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
              rows={3}
            />
          </div>

          <Button
            onClick={handleEdit}
            disabled={!image || !prompt}
            isLoading={loading}
            className="w-full"
            icon="fa-solid fa-paintbrush"
          >
            Edit Image
          </Button>
        </div>

        <div className="bg-slate-900 rounded-xl flex items-center justify-center min-h-[300px] border border-slate-700">
          {loading ? (
             <div className="text-center text-indigo-400 animate-pulse">
               <i className="fa-solid fa-robot text-3xl mb-2"></i>
               <p>AI is editing your photo...</p>
             </div>
          ) : resultImage ? (
            <div className="p-2">
              <img src={resultImage} alt="Edited" className="w-full rounded-lg shadow-lg" />
              <a href={resultImage} download="edited_image.png" className="block mt-4 text-center text-indigo-400 hover:text-indigo-300 text-sm">
                <i className="fa-solid fa-download mr-2"></i>Download Result
              </a>
            </div>
          ) : (
            <div className="text-slate-500 text-center">
              <i className="fa-regular fa-image text-4xl mb-2"></i>
              <p>Edited result will appear here</p>
            </div>
          )}
        </div>
      </div>
    </FeatureCard>
  );
};