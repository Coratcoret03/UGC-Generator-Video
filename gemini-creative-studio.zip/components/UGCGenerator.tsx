import React, { useState } from 'react';
import { generateUGCScript } from '../services/geminiService';
import { Button } from './Button';
import { FeatureCard } from './FeatureCard';
import ReactMarkdown from 'react-markdown';

// Simple markdown component wrapper since we can't use external lib for markdown in this prompt context without adding it to index.html which is messy.
// We will display text as whitespace-pre-wrap.

export const UGCGenerator: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [formData, setFormData] = useState({
    productName: '',
    productType: '',
    targetAudience: '',
    platform: 'TikTok',
    tone: 'Casual & Authentic',
    benefits: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResult('');
    
    try {
      const stream = await generateUGCScript(
        formData.productName,
        formData.productType,
        formData.targetAudience,
        formData.platform,
        formData.tone,
        formData.benefits
      );

      for await (const chunk of stream) {
        setResult(prev => prev + chunk.text);
      }
    } catch (error) {
      console.error(error);
      setResult('Error generating script. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <FeatureCard
      title="UGC Video Concept Creator"
      description="Generate viral-ready UGC scripts optimized for social media conversion using Gemini 2.5 Pro."
      icon="fa-solid fa-clapperboard"
    >
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Product Name</label>
          <input
            required
            name="productName"
            value={formData.productName}
            onChange={handleChange}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            placeholder="e.g., GlowUp Serum"
          />
        </div>
        
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Product Type / Category</label>
          <input
            required
            name="productType"
            value={formData.productType}
            onChange={handleChange}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
            placeholder="e.g., Skincare / Brightening"
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <label className="block text-sm font-medium text-slate-300">Target Audience</label>
          <input
            required
            name="targetAudience"
            value={formData.targetAudience}
            onChange={handleChange}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
            placeholder="e.g., Women 20-35, dry skin issues, busy professionals"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Platform</label>
          <select
            name="platform"
            value={formData.platform}
            onChange={handleChange}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
          >
            <option>TikTok</option>
            <option>Instagram Reels</option>
            <option>YouTube Shorts</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Tone</label>
          <select
            name="tone"
            value={formData.tone}
            onChange={handleChange}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
          >
            <option>Casual & Authentic</option>
            <option>High Energy & Fun</option>
            <option>Emotional & Storytelling</option>
            <option>Professional & Educational</option>
            <option>Humorous</option>
          </select>
        </div>

        <div className="space-y-2 md:col-span-2">
          <label className="block text-sm font-medium text-slate-300">Key Benefits / Problem to Solve</label>
          <textarea
            required
            name="benefits"
            value={formData.benefits}
            onChange={handleChange}
            rows={3}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
            placeholder="e.g., Removes acne scars in 2 weeks, non-sticky formula..."
          />
        </div>

        <div className="md:col-span-2 pt-4">
          <Button type="submit" isLoading={loading} className="w-full py-3 text-lg">
            Generate UGC Concept
          </Button>
        </div>
      </form>

      {result && (
        <div className="mt-8 bg-slate-900 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-semibold text-indigo-400 mb-4">Generated Concept</h3>
          <div className="prose prose-invert max-w-none whitespace-pre-wrap text-slate-300 font-mono text-sm leading-relaxed">
            {result}
          </div>
        </div>
      )}
    </FeatureCard>
  );
};