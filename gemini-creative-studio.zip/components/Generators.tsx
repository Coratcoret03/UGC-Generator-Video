import React, { useState } from 'react';
import { analyzeVideo, analyzeImage, generateImage } from '../services/geminiService';
import { Button } from './Button';
import { FeatureCard } from './FeatureCard';

// --- Video Understanding ---
export const VideoUnderstanding: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [prompt, setPrompt] = useState('Describe what is happening in this video in detail.');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) {
       alert("For browser-based demo, please use small videos (< 50MB) to avoid crashing.");
       return;
    }
    setLoading(true);
    try {
      const text = await analyzeVideo(file, prompt);
      setResult(text || "No response text generated.");
    } catch (e) {
      console.error(e);
      alert("Error analyzing video.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <FeatureCard title="Video Understanding" description="Analyze video content using Gemini 2.5 Pro." icon="fa-solid fa-video">
      <div className="space-y-4">
        <input 
          type="file" 
          accept="video/mp4,video/webm" 
          onChange={(e) => setFile(e.target.files?.[0] || null)} 
          className="block w-full text-sm text-slate-300 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-500 cursor-pointer"
        />
        <textarea 
          value={prompt} 
          onChange={(e) => setPrompt(e.target.value)} 
          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500"
          rows={3}
        />
        <Button onClick={handleAnalyze} disabled={!file} isLoading={loading}>Analyze Video</Button>
        {result && <div className="p-4 bg-slate-900 rounded-lg text-slate-300 whitespace-pre-wrap">{result}</div>}
      </div>
    </FeatureCard>
  );
};

// --- Image Understanding ---
export const ImageUnderstanding: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [prompt, setPrompt] = useState('Describe this image.');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      setPreview(URL.createObjectURL(f));
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const text = await analyzeImage(file, prompt);
      setResult(text || "No response.");
    } catch (e) {
      alert("Error analyzing image.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <FeatureCard title="Image Analysis" description="Get insights from photos using Gemini 2.5 Flash." icon="fa-solid fa-eye">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <input 
            type="file" 
            accept="image/*" 
            onChange={handleFile}
            className="block w-full text-sm text-slate-300 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-500"
          />
          {preview && <img src={preview} alt="Preview" className="w-full rounded-lg border border-slate-700" />}
        </div>
        <div className="space-y-4">
           <textarea 
            value={prompt} 
            onChange={(e) => setPrompt(e.target.value)} 
            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white"
            rows={3}
          />
          <Button onClick={handleAnalyze} disabled={!file} isLoading={loading} className="w-full">Analyze</Button>
          {result && <div className="p-4 bg-slate-900 rounded-lg text-slate-300 whitespace-pre-wrap h-64 overflow-y-auto">{result}</div>}
        </div>
      </div>
    </FeatureCard>
  );
};

// --- Image Generation ---
export const ImageGeneration: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [count, setCount] = useState(1);
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleGen = async () => {
    if (!prompt) return;
    setLoading(true);
    setImages([]);
    try {
      const urls = await generateImage(prompt, count, aspectRatio);
      setImages(urls);
    } catch (e) {
      console.error(e);
      alert("Generation failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <FeatureCard title="Imagen 4 Generator" description="Create high-fidelity images from text." icon="fa-solid fa-palette">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-xs font-medium text-slate-400 mb-1 ml-1">Prompt</label>
            <input 
              type="text" 
              value={prompt} 
              onChange={(e) => setPrompt(e.target.value)} 
              placeholder="A futuristic city with neon lights..." 
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div className="w-full md:w-32">
            <label className="block text-xs font-medium text-slate-400 mb-1 ml-1">Quantity</label>
            <select 
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
            >
              <option value={1}>1 Image</option>
              <option value={2}>2 Images</option>
              <option value={3}>3 Images</option>
              <option value={4}>4 Images</option>
            </select>
          </div>
          <div className="w-full md:w-32">
            <label className="block text-xs font-medium text-slate-400 mb-1 ml-1">Size</label>
            <select 
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500"
            >
              <option value="1:1">Square (1:1)</option>
              <option value="16:9">Landscape (16:9)</option>
              <option value="9:16">Portrait (9:16)</option>
              <option value="4:3">Photo (4:3)</option>
              <option value="3:4">Portrait (3:4)</option>
            </select>
          </div>
          <div className="flex items-end">
             <Button onClick={handleGen} disabled={!prompt} isLoading={loading} className="w-full md:w-auto">Generate</Button>
          </div>
        </div>

        <div className="bg-slate-900 min-h-[300px] rounded-xl border border-slate-700 p-4">
          {loading ? (
             <div className="h-[300px] flex items-center justify-center">
               <div className="text-center">
                 <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-indigo-500 mb-2"></div>
                 <p className="text-slate-400">Generating {count} image{count > 1 ? 's' : ''}...</p>
               </div>
             </div>
          ) : images.length > 0 ? (
             <div className={`grid gap-4 ${images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
               {images.map((img, idx) => (
                 <div key={idx} className="relative group rounded-lg overflow-hidden">
                   <img src={img} alt={`Generated ${idx + 1}`} className="w-full h-auto object-cover rounded-lg" />
                   <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                     <a 
                       href={img} 
                       download={`generated_${Date.now()}_${idx}.jpeg`}
                       className="bg-indigo-600 text-white px-4 py-2 rounded-full hover:bg-indigo-700 flex items-center"
                     >
                       <i className="fa-solid fa-download mr-2"></i> Download
                     </a>
                   </div>
                 </div>
               ))}
             </div>
          ) : (
            <div className="h-[300px] flex flex-col items-center justify-center text-slate-500">
               <i className="fa-regular fa-image text-4xl mb-2"></i>
               <span>Enter a prompt to start creating</span>
            </div>
          )}
        </div>
      </div>
    </FeatureCard>
  );
};