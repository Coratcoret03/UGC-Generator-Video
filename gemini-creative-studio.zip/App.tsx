import React, { useState } from 'react';
import { NavItem, FeatureView } from './types';
import { UGCGenerator } from './components/UGCGenerator';
import { ImageEditor } from './components/ImageEditor';
import { VeoAnimator } from './components/VeoAnimator';
import { VideoUnderstanding, ImageUnderstanding, ImageGeneration } from './components/Generators';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<FeatureView>(FeatureView.UGCGenerator);

  const navItems: NavItem[] = [
    { id: FeatureView.UGCGenerator, label: 'UGC Studio', icon: 'fa-solid fa-clapperboard', description: 'Script viral concepts' },
    { id: FeatureView.VeoAnimation, label: 'Veo Animator', icon: 'fa-solid fa-film', description: 'Animate static photos' },
    { id: FeatureView.ImageEditing, label: 'Nano Editor', icon: 'fa-solid fa-wand-magic-sparkles', description: 'Edit with text' },
    { id: FeatureView.ImageGeneration, label: 'Imagen 4', icon: 'fa-solid fa-palette', description: 'Generate images' },
    { id: FeatureView.VideoUnderstanding, label: 'Video Analysis', icon: 'fa-solid fa-video', description: 'Analyze video' },
    { id: FeatureView.ImageUnderstanding, label: 'Image Analysis', icon: 'fa-solid fa-eye', description: 'Analyze photos' },
  ];

  const renderContent = () => {
    switch (currentView) {
      case FeatureView.UGCGenerator: return <UGCGenerator />;
      case FeatureView.VeoAnimation: return <VeoAnimator />;
      case FeatureView.ImageEditing: return <ImageEditor />;
      case FeatureView.ImageGeneration: return <ImageGeneration />;
      case FeatureView.VideoUnderstanding: return <VideoUnderstanding />;
      case FeatureView.ImageUnderstanding: return <ImageUnderstanding />;
      default: return <UGCGenerator />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-72 bg-slate-900 border-r border-slate-800 flex-shrink-0 sticky top-0 h-auto md:h-screen overflow-y-auto z-10">
        <div className="p-6">
          <div className="flex items-center space-x-3 mb-8">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <i className="fa-solid fa-layer-group text-white text-xl"></i>
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-indigo-400">
              Creative<br/>Studio
            </h1>
          </div>

          <nav className="space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`w-full flex items-start p-3 rounded-xl transition-all duration-200 group ${
                  currentView === item.id 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50' 
                    : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <i className={`${item.icon} mt-1 mr-3 text-lg w-6 text-center ${
                  currentView === item.id ? 'text-indigo-200' : 'text-slate-500 group-hover:text-indigo-400'
                }`}></i>
                <div className="text-left">
                  <div className="font-medium">{item.label}</div>
                  <div className={`text-xs mt-0.5 ${
                    currentView === item.id ? 'text-indigo-200' : 'text-slate-600 group-hover:text-slate-400'
                  }`}>
                    {item.description}
                  </div>
                </div>
              </button>
            ))}
          </nav>
        </div>
        
        <div className="p-6 border-t border-slate-800 mt-auto">
          <div className="flex items-center space-x-2 text-xs text-slate-600">
            <span>Powered by Google Gemini 2.5</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-12 relative">
        {/* Background Decoration */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
           <div className="absolute top-[-10%] right-[-5%] w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl"></div>
           <div className="absolute bottom-[-10%] left-[-5%] w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10">
          <header className="flex justify-between items-center mb-8 md:hidden">
             <span className="text-sm font-mono text-slate-500">Gemini Creative Suite</span>
          </header>
          
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;